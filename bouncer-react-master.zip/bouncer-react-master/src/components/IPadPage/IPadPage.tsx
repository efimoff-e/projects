import React from 'react';

const IPadPage: React.FC = () => {
  return (
    <h1>IPad</h1>
  )
}

export default IPadPage;