import React from 'react';

const IPhonePage: React.FC = () => {
  return (
    <h1>IPhonePage</h1>
  )
}

export default IPhonePage;