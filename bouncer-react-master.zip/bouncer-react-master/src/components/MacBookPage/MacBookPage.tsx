import React from 'react';

const MacBookPage: React.FC = () => {
  return (
    <h1>MacBookPage</h1>
  )
}

export default MacBookPage;