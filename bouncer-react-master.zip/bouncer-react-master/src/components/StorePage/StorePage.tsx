import React from 'react';

const StorePage: React.FC = () => {
  return (
    <h1>Store</h1>
  )
}

export default StorePage;