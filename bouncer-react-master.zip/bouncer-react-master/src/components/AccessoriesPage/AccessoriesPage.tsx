import React from 'react';

const AccessoriesPage: React.FC = () => {
  return (
    <h1>AccessoriesPage</h1>
  )
}

export default AccessoriesPage;